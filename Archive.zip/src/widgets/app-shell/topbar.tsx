import type { AppDispatch, RootState } from '@/store/index';

import { useEffect, useRef, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { ChevronDown, LogOut, Moon, Sun } from 'lucide-react';

import { authApi } from '@/services/auth.service';
import { logout } from '@/store/features/auth.slice';

type Props = {
  isDark: boolean;
  onToggleTheme: () => void;
};

function initialsFromUserName(name: string): string {
  const s = name.trim();
  if (!s) return '?';
  const parts = s.split(/\s+/).filter(Boolean);
  if (parts.length > 1) return (parts[0]![0]! + parts[1]![0]!).toUpperCase();
  if (s.length === 1) return s.toUpperCase();
  return (s[0]! + s[1]!).toUpperCase();
}

export function Topbar({ isDark, onToggleTheme }: Props) {
  const dispatch = useDispatch<AppDispatch>();
  const auth = useSelector((state: RootState) => state.auth);
  const user = auth?.data?.user;
  const [menuOpen, setMenuOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  const fullName = [user?.firstName?.trim(), user?.lastName?.trim()]
    .filter(Boolean)
    .join(' ');
  const displayName =
    fullName || user?.name?.trim() || user?.username?.trim() || 'Test user';
  const initials = initialsFromUserName(displayName);

  useEffect(() => {
    if (!menuOpen) return;
    const onDoc = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', onDoc);
    return () => document.removeEventListener('mousedown', onDoc);
  }, [menuOpen]);

  const handleLogout = () => {
    setMenuOpen(false);
    dispatch(logout());
    dispatch(authApi.util.invalidateTags([{ type: 'CurrentUser', id: 'ME' }]));
  };

  return (
    <header
      className={[
        'flex h-14 shrink-0 items-center gap-3 border-b px-4 md:px-6',
        isDark
          ? 'border-slate-800/80 bg-slate-900/80 text-slate-100 backdrop-blur-md'
          : 'border-slate-200 bg-white/90 text-slate-900 backdrop-blur-md',
      ].join(' ')}
    >
      <div className="ml-auto flex shrink-0 items-center gap-1 sm:gap-2">
        <button
          type="button"
          onClick={onToggleTheme}
          className={[
            'flex h-10 w-10 items-center justify-center rounded-lg border transition',
            isDark
              ? 'border-slate-700 bg-slate-800/60 text-amber-300 hover:bg-slate-800'
              : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50',
          ].join(' ')}
          aria-label={isDark ? 'İşıqlı mövzu' : 'Qaranlıq mövzu'}
        >
          {isDark ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
        </button>

        <div className="relative" ref={menuRef}>
          <button
            type="button"
            onClick={() => setMenuOpen((o) => !o)}
            aria-expanded={menuOpen}
            aria-haspopup="menu"
            className={[
              'flex items-center gap-2 rounded-lg border px-2 py-1.5 text-left text-sm transition',
              isDark
                ? 'border-slate-700 bg-slate-800/60 text-slate-200 hover:bg-slate-800'
                : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50',
            ].join(' ')}
          >
            <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-blue-600 text-xs font-semibold text-white">
              {initials}
            </span>
            <span className="min-w-0 max-w-[10rem]">
              <span className="block truncate font-medium leading-tight">
                {displayName}
              </span>
            </span>
            <ChevronDown
              className={[
                'h-4 w-4 shrink-0 opacity-70 transition',
                menuOpen ? 'rotate-180' : '',
              ].join(' ')}
            />
          </button>

          {menuOpen && (
            <div
              role="menu"
              className={[
                'absolute right-0 z-[100] mt-1 min-w-[11rem] overflow-hidden rounded-lg border py-1 shadow-xl',
                isDark
                  ? 'border-slate-700 bg-slate-900 text-slate-100'
                  : 'border-slate-200 bg-white text-slate-900',
              ].join(' ')}
            >
              <button
                type="button"
                role="menuitem"
                onClick={handleLogout}
                className={[
                  'flex w-full items-center gap-2 px-3 py-2 text-left text-sm transition',
                  isDark
                    ? 'hover:bg-red-950/50 hover:text-red-200'
                    : 'hover:bg-red-50 hover:text-red-700',
                ].join(' ')}
              >
                <LogOut className="h-4 w-4 shrink-0" />
                Çıxış
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
